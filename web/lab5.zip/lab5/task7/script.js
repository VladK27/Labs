//task 1
function equal(num1, num2){
    alert(num1 == num2);
    return (num1 == num2);
}
//task 2
function compare(num1, num2){
    alert(10 < (parseInt(num1) + parseInt(num2)));
    return (10 < (parseInt(num1) + parseInt(num2)));
}
//task 3
function isneg(num1){
    alert(num1 < 0);
    return (num1 < 0);
}