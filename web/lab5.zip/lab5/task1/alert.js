
function myalert(){
    let name;
    name = prompt("Ваш имя?");
    if(name != null) alert(name);
    
}