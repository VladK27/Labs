let num1;
let num2;
let compare = () => (num1 = parseInt(prompt('Введите 1 число'))) == (num2 = parseInt(prompt('Введите 2 число'))) ? 0 : (num1 > num2 ? -1 : 1);

